init 1:
    image b_pool_0 = "patches/10a_android/b_pool_0.webp"
    image c_pool_0 = "patches/10a_android/c_pool_0.webp"
    image e_dungeon_0 = "patches/10a_android/e_dungeon_0.webp"
    image g_dungeon_0 = "patches/10a_android/g_dungeon_0.webp"
    image hint_clean_1 = "patches/10a_android/hint_clean_1.webp"
    image hint_clean_2 = "patches/10a_android/hint_clean_2.webp"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
