from dataclasses import dataclass
from pydub import AudioSegment
@dataclass
class Loop:   
    out_name: str
    total_frame: int
    hit_times: int
    hit_frame: int
    video_frame_rate: float = 60.0
    format: str = "ogg"
    # Loop(out_name, total_frame, hit_times, hit_frame, video_frame_rate)

loops = [
    # Loop("a_train_inti_2_73", 33, 1, 32),
    # Loop("a_train_inti_2_74", 33, 1, 3),
    # Loop("acg_duo_5_80", 34, 1, 20),
    # Loop("acg_duo_5_81", 25, 1, 24),
    # Loop("acg_duo_5_83", 20, 1, 17),
    # Loop("acg_duo_5_86", 69, 2, 4),
    # Loop("acg_duo_5_87", 34, 1, 11),
    # Loop("acg_duo_5_92", 35, 1, 12),
    # Loop("acg_duo_5_93", 34, 1, 0),
    # Loop("b_outdoors_1_1", 34, 1, 33),
    # Loop("b_outdoors_1_2", 204, 6, 19),
    # Loop("b_train_sha_3_59", 34, 1, 33),
    # Loop("b_train_sha_3_60", 272, 8, 31),
    # Loop("b_train_sha_3_64", 34, 1, 1),
    # Loop("b_train_sha_3_65", 34, 1, 31),
    # Loop("g_train_inti_2_37", 34, 1, 24),
    # Loop("g_train_inti_2_38", 35, 1, 25),
    # Loop("g_train_inti_2_39", 34, 1, 0),
    # Loop("g_train_inti_2_40", 34, 1, 30),
    # Loop("g_train_inti_2_41", 25, 1, 8),
    # Loop("ec5_136", 40, 1, 27),
    # Loop("ec5_137", 41, 1, 18),
    # Loop("ec5_138", 67, 2, 8),
    # Loop("ec5_139", 33, 1, 7),
    # Loop("ec5_150", 248, 8, 30),
    # Loop("ec5_151", 31, 1, 22),
    # Loop("c_dungeon_2_2", 32, 1, 7),
    # Loop("c_dungeon_2_3", 26, 1, 5),
    # Loop("c_train_inti_3_50", 31, 1, 22),
    # Loop("c_train_inti_3_51", 26, 1, 11),
    # Loop("c_train_sub_2_49", 31, 1, 27),
    # Loop("c_train_sub_2_50", 31, 1, 5),
    # Loop("c_train_sub_2_77", 31, 1, 12),
    # Loop("c_train_sub_2_78", 31, 1, 8),
    # Loop("c_train_sub_2_79", 31, 1, 21),
    # Loop("cde_duo_6_1", 32, 1, 17),
    # Loop("cde_duo_6_2", 69, 2, 28),
    # Loop("cde_duo_6_3", 31, 1, 27),
    # Loop("cde_duo_6_5", 32, 1, 19),
    # Loop("cde_duo_6_30", 250, 8, 17),
    # Loop("cde_duo_6_31", 126, 4, 0),
    # Loop("d_train_sexskill_2_44", 39, 1, 5),
    # Loop("d_train_sexskill_2_45", 53, 2, 6),
    # Loop("d_train_sexskill_2_46", 25, 1, 8),
    # Loop("g_train_sub_3_40", 39, 1, 24),
    # Loop("g_train_sub_3_41", 31, 1, 2),
    # Loop("g_train_sub_3_42", 30, 1, 11),
    # Loop("zhong_1", total_frame=34*50, hit_times=50, hit_frame=0, format="wav"),
    # Loop("zhong_3", total_frame=38*50, hit_times=50, hit_frame=0, format="wav"),
    # Loop("zhong_4", total_frame=35*50, hit_times=50, hit_frame=0, format="wav"),
    # Loop("acg_duo_6_1", 34, 1, 0),
    # Loop("a_dungeon_2_3", 41, 1, 12),
    # Loop("a_outdoors_1_17", 31, 1, 18),
    # Loop("a_outdoors_1_18", 31, 1, 11),
    # Loop("de_duo1_68", 93, 3, 16),
    # Loop("de_duo1_69", 93, 3, 4),
    # Loop("e_outdoors_2_6", 39, 1, 20),
    # Loop("e_outdoors_2_7", 39, 1, 38),
    # Loop("e_train_sha_2_24", 35, 1, 17),
    # Loop("e_train_sha_2_25", 31, 1, 0),
    # Loop("e_train_sha_2_33", 31, 1, 9),
    # Loop("e_train_sha_2_34", 30, 1, 2),
    # Loop("a_dungeon_2_4", 42, 1, 32),
    # Loop("acg_duo_6_4", 38, 1, 36),

    # Loop("c_action_sha_2_18", 39, 1, 35),
    # Loop("c_action_sha_2_28", 31, 1, 11),
    # Loop("c_action_sha_2_29", 32, 1, 31),
    # Loop("c_action_sha_2_30", 31, 1, 12),
    # Loop("d_train_sha_2_39", 31, 1, 25),
    # Loop("d_train_sha_2_40", 31, 1, 27),
    # Loop("e_action_sub_2_32", 39, 1, 12),
    # Loop("e_action_sub_2_33", 39, 1, 13),
    # Loop("g_action_sub_3_36", 39, 1, 3),
    # Loop("g_action_sub_3_37", 39, 1, 38),
    # Loop("g_action_sub_3_42", 32, 1, 31),
    # Loop("g_action_sub_3_43", 32, 1, 5),

    # Loop("acg_final_1_27", 39, 1, 12),
    # Loop("acg_final_1_28", 39, 1, 18),
    # Loop("acg_final_1_49", 39, 1, 29),
    # Loop("acg_final_1_50", 39, 1, 36),
    # Loop("acg_final_1_65", 35, 1, 2),
    # Loop("acg_final_1_66", 35, 1, 27),
    # Loop("acg_final_1_109", 34, 1, 11),
    # Loop("acg_final_1_110", 34, 1, 11),
    # Loop("acg_final_1_119", 39, 1, 3),
    # Loop("acg_final_1_120", 39, 1, 21),
    # Loop("acg_final_1_135", 39, 1, 24),
    # Loop("acg_final_1_136", 20, 1, 3),
    # Loop("bm_duo_1_32", 34, 1, 21),
    # Loop("bm_duo_1_33", 34, 1, 11),
    # Loop("bm_duo_1_46", 36, 1, 19),
    # Loop("bm_duo_1_50", 35, 1, 10),
    # Loop("bm_duo_1_51", 34, 1, 17),
    # Loop("ce_duo_1_33", 33, 1, 0),
    # Loop("ce_duo_1_34", 32, 1, 4),
    # Loop("d_train_sexskill_3_17", 34, 1, 1),
    # Loop("d_train_sexskill_3_18", 34, 1, 9),
    # Loop("d_train_sexskill_3_19", 33, 1, 1),

    Loop("a_final_19", 33, 1, 5),
    Loop("a_final_20", 33, 1, 26),
    Loop("a_final_27", 30, 1, 22),
    Loop("a_final_28", 30, 1, 2),
    Loop("a_final_76", 33, 1, 32),
    Loop("a_final_77", 28, 1, 15),
    Loop("a_final_78", 57, 2, 0),
    Loop("a_final_103", 48, 1, 4),
    Loop("a_final_104", 31, 1, 8),
    Loop("a_final_105", 24, 1, 0),
    Loop("bm_final_40", 39, 1, 12),
    Loop("bm_final_41", 40, 1, 34),
    Loop("bm_final_42", 40, 1, 5),
    Loop("bm_final_87", 40, 1, 4),
    Loop("bm_final_88", 33, 1, 8),
    Loop("bm_final_89", 35, 1, 7),
    Loop("bm_final_94", 56, 1, 13),
    Loop("bm_final_95", 28, 1, 14),
    Loop("bm_final_96", 27, 1, 12),
    Loop("c_final_1", 30, 1, 17),
    Loop("c_final_2", 23, 1, 14),
    Loop("c_final_3", 21, 1, 9),
    Loop("c_final_56", 26, 1, 6),
    Loop("c_final_57", 27, 1, 1),
    Loop("c_final_58", 30, 1, 26),
    Loop("c_final_59", 30, 1, 23),
    Loop("c_final_109", 34, 1, 15),
    Loop("c_final_110", 34, 1, 3),
    Loop("c_final_113", 26, 1, 0),
    Loop("c_final_114", 26, 1, 23),
    Loop("cde_final_44", 38, 1, 12),
    Loop("cde_final_45", 38, 1, 24),
    Loop("cde_final_47", 28, 1, 2),
    Loop("cde_final_48", 31, 1, 16),
    Loop("cde_final_50", 26, 1, 7),
    Loop("cde_final_51", 26, 1, 20),
    Loop("cde_final_88", 35, 1, 11),
    Loop("cde_final_89", 36, 1, 21),
    Loop("cde_final_138", 31, 1, 11),
    Loop("cde_final_139", 31, 1, 15),
    Loop("cde_final_140", 32, 1, 16),
    Loop("cde_final_151", 38, 1, 2),
    Loop("cde_final_152", 39, 1, 9),
    Loop("final_final_5", 37, 1, 35),
    Loop("final_final_6", 35, 1, 7),
    Loop("final_final_79", 40, 1, 26),
    Loop("final_final_80", 25, 1, 6),
    Loop("final_final_105", 32, 1, 16),
    Loop("final_final_106", 34, 1, 29),
    Loop("final_final_168", 28, 1, 2),
    Loop("final_final_169", 28, 1, 2),
    Loop("final_final_170", 24, 1, 3),
    Loop("final_final_178", 27, 1, 6),
    Loop("final_final_179", 28, 1, 19),
    Loop("final_final_182", 33, 1, 2),
    Loop("final_final_183", 31, 1, 19),
]


for loop in loops:
    out_name = loop.out_name
    total_frame = loop.total_frame
    hit_times = loop.hit_times
    hit_frame = loop.hit_frame
    video_frame_rate = loop.video_frame_rate
    format = loop.format

    frame_length = 1000.0 / video_frame_rate
    loop_total_frame = total_frame/hit_times
    final = AudioSegment.empty()

    speed_type = "slow"
    expected_hit_times: int = 18
    if loop_total_frame <= 30:
        speed_type = "quickest"
    elif loop_total_frame <= 40:
        speed_type = "quick"
        expected_hit_times = 19
    elif loop_total_frame <= 50:
        speed_type = "slow"
    elif loop_total_frame > 50:
        speed_type = "slowest"
        expected_hit_times = 10

    sample = AudioSegment.from_file(f'{speed_type}/1.wav')
    frame_rate = sample.frame_rate
    pre_length = hit_frame * frame_length
    print(f"pre_length = {pre_length}")

    # print(f"loop_total_frame = {loop_total_frame}")
    post_length = (loop_total_frame - hit_frame) * frame_length
    print(f"post_length = {post_length}\n\n")

    for hit in range(hit_times):
        hit = hit % expected_hit_times + 1
        fname = f'{speed_type}/{hit}.wav'
        sample = AudioSegment.from_file(fname)
        sample_length = len(sample)

        if sample_length <= post_length:
            pre_silence = AudioSegment.silent(duration=pre_length, frame_rate=frame_rate)

            post_silence_length = post_length - sample_length
            post_silence = AudioSegment.silent(duration=post_silence_length, frame_rate=frame_rate)

            loop = pre_silence + sample + post_silence

        else:
            sample_pt2_length = sample_length - post_length

            silence_length = pre_length - sample_pt2_length
            silence = AudioSegment.silent(duration=silence_length, frame_rate=frame_rate)

            loop = sample[:sample_pt2_length] + silence + sample[-post_length:]
            
            # print(f"sample_part_2_length = {sample_pt2_length}")
            # print(f"silence_length = {silence_length}")
            # print(f"post_length = {post_length}")

        # print(f"loop_length = {len(loop)}")
        final += loop

    print("================================")
    print("final: ")
    print(f"length = {len(final)}")
    print(f"estimated total frame = {len(final)/frame_length}")
    final.export(f"{out_name}.{format}", format=format)
