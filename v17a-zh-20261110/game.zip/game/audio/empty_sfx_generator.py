import traceback
from pydub import AudioSegment

try:
    from skimage.metrics import structural_similarity as ssim
    import cv2
    import numpy as np
    import matplotlib.pyplot as plt
    import os
    import sys

    def compare_images(imageA, imageB, count):
        imageA = cv2.cvtColor(imageA, cv2.COLOR_RGB2GRAY)
        imageB = cv2.cvtColor(imageB, cv2.COLOR_RGB2GRAY)

        s = ssim(imageA, imageB)
        return s


    working_dir = os.getcwd()
    print(f"working dir: {working_dir}")

    input_files = sys.argv[1:]
    print(f"input files: {input_files}")
    
    for input_file in input_files:

        name = input_file.replace(".mp4", ".ogg")
        AudioSegment.silent(duration=1.0, frame_rate=16000).export(name, format="ogg")

    print("completed")    

except:
    traceback.print_exc()

finally:
    input()
